# Dynamic grid

A look at using `auto-fit` and a few other little things to make a dynamic grid layout.

## Tutorial

This code is based on [this YouTube tutorial](https://youtu.be/sKFW3wek21Q).
